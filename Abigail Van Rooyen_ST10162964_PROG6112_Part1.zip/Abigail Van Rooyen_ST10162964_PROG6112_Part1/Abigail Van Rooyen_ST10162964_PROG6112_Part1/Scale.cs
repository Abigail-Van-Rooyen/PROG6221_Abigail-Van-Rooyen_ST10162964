﻿using System;
using System.Collections;
namespace Abigail_Van_Rooyen_ST10162964_PROG6112_Part1
{
    internal class Scale
    {
        //Halfing the quantity
        public void Half(ArrayList iQuan, ArrayList oriValue)
        {
            //halfing the amounts in the array
            for (int i = 0; i < oriValue.Count; i++)
            {
                iQuan[i] = Convert.ToDouble(oriValue[i])*0.5;
            }

            //Confirmation message
            System.Console.WriteLine("The values have been updated!\n" +
                "-------------------------------------------------------\n");
        }
        //Doubling the quantity
        public void Double(ArrayList iQuan, ArrayList oriValue)
        {
            //Doubling the amounts in the array
            for (int i = 0; i < oriValue.Count; i++)
            {
                iQuan[i] = Convert.ToDouble(oriValue[i]) * 2;
            }

            //Confirmation message
            System.Console.WriteLine("The values have been updated!\n" +
                "-------------------------------------------------------\n");
        }
        //Tripling the quantity
        public void Triple(ArrayList iQuan, ArrayList oriValue)
        {
            //Tripling the amounts in the array
            for (int i = 0; i < oriValue.Count; i++)
            {
                iQuan[i] = Convert.ToDouble(oriValue[i]) * 3;
            }

            //Confirmation message
            System.Console.WriteLine("The values have been updated!\n" +
                "-------------------------------------------------------\n");
        }
        //Resetting the value back to the original
        public void Reset(ArrayList iQuan, ArrayList oriValue)
        {
            iQuan.Clear();
            //The value will reset to the original
            for (int i = 0; i < oriValue.Count; i++)
            {
                iQuan.Add(oriValue[i]);
            }

            //Confirmation message
            System.Console.WriteLine("The values have been reset!\n" +
                "-------------------------------------------------------\n");
        }
    }
}
