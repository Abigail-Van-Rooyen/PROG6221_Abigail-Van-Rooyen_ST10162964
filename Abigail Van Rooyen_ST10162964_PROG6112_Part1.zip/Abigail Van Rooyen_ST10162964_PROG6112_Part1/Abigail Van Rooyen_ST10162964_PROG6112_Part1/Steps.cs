﻿using System.Collections;

namespace Abigail_Van_Rooyen_ST10162964_PROG6112_Part1
{
    internal class Steps
    {
        //Recording the steps from the users input
        public void StepDetails(ArrayList steps, int x)
        {
            System.Console.WriteLine("Enter instructions for step number " + (x + 1));
            steps.Add(System.Console.ReadLine());
            System.Console.WriteLine("-------------------------------------------------------");
        }
    }
}
