﻿using System;
using System.Collections;

namespace Abigail_Van_Rooyen_ST10162964_PROG6112_Part1
{
    internal class Ingredients
    {
        //Displaying and storing the user's input for the ingredient name
        public void IngredName(ArrayList iName,int x)
        {
            System.Console.WriteLine("Enter ingredient number " + (x + 1) + "'s name ");
            iName.Add(System.Console.ReadLine());
            System.Console.WriteLine("-------------------------------------------------------");
        }

        //Displaying and storing the user's input for the ingredient quantity
        public void IngredQuan(ArrayList iQuan, ArrayList iName, int x, ArrayList oriValue)
        {
            System.Console.WriteLine("Enter ingredient quantity for the " + iName[x]);
            iQuan.Add(Convert.ToDouble(System.Console.ReadLine()));
            oriValue.Add(Convert.ToDouble(iQuan[x]));
            System.Console.WriteLine("-------------------------------------------------------");
        }

        //Displaying and storing the user's input for the unit of measurement
        public void IngredMeas(ArrayList iMeas)
        {
            System.Console.WriteLine("Enter unit of measurement: ");
            iMeas.Add(System.Console.ReadLine());
            System.Console.WriteLine("_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
        }

    }
}
