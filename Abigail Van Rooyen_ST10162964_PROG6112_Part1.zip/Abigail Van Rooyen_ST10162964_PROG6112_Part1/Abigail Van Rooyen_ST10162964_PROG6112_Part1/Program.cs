﻿using System;
using System.Collections;
namespace Abigail_Van_Rooyen_ST10162964_PROG6112_Part1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Class objects
            var i = new Ingredients();
            var s = new Steps();
            var sc = new Scale();

            //Arraylist declaration for the ingredients name
            ArrayList iName = new ArrayList();
            //Arraylist declaration for the ingredient quantity
            ArrayList iQuan = new ArrayList();
            //Arraylist declaration for the unit of measurement
            ArrayList iMeas = new ArrayList();
            //Arraylist declaration for the steps of the recipe
            ArrayList steps = new ArrayList();
            //Arraylist to store the original quantity number
            ArrayList oriValue = new ArrayList();

            //A string for capturing the option that the user picks in the menu
            string option = "";
            //A string for capturing the option that the user picks in the scaling menu
            string opScale = "";
            //A string for capturing the recipe name
            String rName = "";
            //Storing the amount of ingredients
            int ingredAm = 0;
            //Storing the amount of steps
            int stepAm = 0;

            do
            {
                //Welcome screen and options menu
                System.Console.WriteLine("_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n" +
                    "Welcome to your recipe book!\n" +
                    "_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");

                System.Console.WriteLine("-------------------------------------------------------\n" +
                    "Would you like to: \n" +
                    "-------------------------------------------------------\n" +
                    "1) Capture a recipe\n" +
                    "2) Display a recipe\n" +
                    "3) Rescale a recipes quantities\n" +
                    "4) Revert quantities to their original state\n" +
                    "5) Clear all data\n" +
                    "6) Exit\n" +
                    "-------------------------------------------------------\n");
                option = System.Console.ReadLine();

                //Capturing the recipe
                if (option.Equals("1"))
                {
                    //Prompting the user for the recipe name
                    System.Console.WriteLine("Enter the recipe name: ");
                    rName = Console.ReadLine();

                    //Promting the user for the number of ingredients
                    System.Console.WriteLine("Enter amount of ingredients required: ");
                    ingredAm = Convert.ToInt32(System.Console.ReadLine());
                    System.Console.WriteLine("-------------------------------------------------------");

                    //For loop to populate the arraylist fully
                    for (int x = 0; x < ingredAm; x++)
                    {
                        //Ingredient Name
                        i.IngredName(iName, x);

                        //Ingredient quantity
                        i.IngredQuan(iQuan, iName, x, oriValue);

                        //Ingredient unit of measurement
                        i.IngredMeas(iMeas);

                    }

                    //Number of steps
                    System.Console.WriteLine("Enter amount of steps");
                    stepAm = Convert.ToInt32(System.Console.ReadLine());
                    System.Console.WriteLine("-------------------------------------------------------");

                    //For loop to populate the corresponding arrays
                    for (int x = 0; x < stepAm; x++)
                    {
                        s.StepDetails(steps, x);
                    }
                }
                
                if (option.Equals("2") && rName!= "")
                {
                    
                    for (int x = 0; x < ingredAm; x++)
                    {
                        try
                        {
                            // Ingredients display
                            System.Console.WriteLine("\n_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n" +
                                "Recipe: " + rName + "\n" +
                                "_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n");
                            System.Console.WriteLine("Ingredients: \n" +
                                "-------------------------------------------------------");
                            System.Console.WriteLine(iName[x] + " |" + iQuan[x] + " " + iMeas[x]);
                        }
                        catch (Exception e)
                        {
                            System.Console.WriteLine("There is no data to display!");
                        }
                        
                    }
                        //Steps display
                        System.Console.WriteLine("-------------------------------------------------------");
                        for (int x = 0; x < stepAm; x++)
                        {
                            System.Console.WriteLine("Step " + (x + 1) + ": \n" + steps[x]);
                            System.Console.WriteLine("-------------------------------------------------------\n");
                            System.Console.WriteLine("_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
                        }
                }

                //Error message if no recipe has been captured
                else if (option.Equals("2") && rName.Equals("") || rName.Equals(null))
                {
                    System.Console.WriteLine("There is no recipe to display! \n \n");
                
                //Rescaling the recipe quantity
                }else if (option.Equals("3"))
                {
                    System.Console.WriteLine("Select your scaling preference:\n" +
                        "-------------------------------------------------------\n" +
                        "1) Half (0.5)\n" +
                        "2) Double (x2)\n" +
                        "3) Triple (x3)\n");
                    opScale = System.Console.ReadLine();
                    
                    //If the user picks 1...
                    if (opScale.Equals("1"))
                    {
                        sc.Half(iQuan,oriValue);

                    //If the user picks 2...
                    }else if (opScale.Equals("2"))
                    {
                        sc.Double(iQuan, oriValue);
                    

                    //If the user picks 3...
                    }else if (opScale.Equals("3"))
                    {
                        sc.Triple(iQuan, oriValue);
                    }
                    else
                    {
                        System.Console.WriteLine("Invalid option, please try again");
                    }

                //Restoring the original values
                }else if (option.Equals("4"))
                {
                    sc.Reset(iQuan,oriValue);

                //Clearing all recipe data
                }else if (option.Equals("5"))
                {
                    rName = "";
                    iName.Clear();
                    iQuan.Clear();
                    iMeas.Clear();
                    steps.Clear();
                    oriValue.Clear();
                    System.Console.WriteLine("All data has been cleared! \n");
                }
            //Exit
            } while (option != "6");

            Console.ReadLine();
        }
    }
}
